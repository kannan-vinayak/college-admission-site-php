<?php
 $link =new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
        if(!$link)
        {
           die('could not connect: ' . $link->connect_error());
        }
        $user=$_GET['user'];
       //$user = $_SESSION["email"];
  if(isset($_POST['submit']))
{
         
         $a=$_POST['diploma'];
         $c=$_POST['mark'];
         $d=$_POST['pregno'];
         $e=$_POST['college'];
         $f=$_POST['dept'];
         $g=$_POST['doj'];
         $h=$_POST['med'];
         $ss=$_SESSION["abc"];
         $sql = " UPDATE `vel` SET  `diploma`='$a',`mark`='$c',`pregno`='$d',`college`='$e',`dept`='$f',`doj`='$g',`med`='$h' WHERE `num`='$user' OR `ref`='$user' ";
         
       if (mysqli_query($link,$sql,MYSQLI_USE_RESULT)) 
       {           
                header("Location:pdf1.php");          
       }

       mysqli_close($link);
	
} ?>