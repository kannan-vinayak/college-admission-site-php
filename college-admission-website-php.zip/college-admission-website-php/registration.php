<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Velammal Institute of Technology</title>
    <link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/52874c72f6.js" crossorigin="anonymous"></script>
    <script src="main.js" type="text/js"></script>
    <style>
         .bg{
    background-size: 100%;
    background-color: #fff;
}
.form-container {
    width: 100%;
    position: absolute;
    top: 5vh;
    background: #fff;
    padding: 30px;
    border-radius:25px ;
    box-shadow: 0px 0px 25px 0px #000;
}
    </style>
</head>
<body>
<?php
$link = new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
       if(!$link)
       {
          die('could not connect: ' . $link->connect_error());
       }

 if(isset($_POST['submit']))
{    
        $a=$_POST['fname'];
        $b=$_POST['lname'];
        $c=$_POST['dob'];
        $d=$_POST['email'];
        $w=$_POST['gender'];
        $g=$_POST['num'];
        $h=$_POST['anum'];
        $i=$_POST['living'];
        $j=$_POST['pname'];
        $k=$_POST['poccu'];
        $l=$_POST['mtongue'];
        $m=$_POST['tenth'];
        $mk=$_POST['percent'];
        $n=$_POST['address'];
        $o=$_POST['district'];
        $p=$_POST['state'];
        $q=$_POST['pincode'];
        $r=$_POST['religion'];
        $s=$_POST['registered'];
        $t=$_POST['choice'];
        $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
        $u=$_POST['fpre'];
        $v=$_POST['spre'];
        $x=$_POST['tpre'];
        $z=1111;
        $key=rand(10000,100000);
        
        
     $sql = "INSERT INTO `vel` (`fname`,`lname`,`dob`,`email`,`gender`,`num`,`anum`,`living`,`pname`,`poccu`,`mtongue`,`tenth`,`address`,`district`,`state`,`pincode`,`religion`,`registered`,`choice`,`image`,`fpre`,`spre`,`tpre`,`ref`,`regno`,`school`,`grou`,`vel`,`bos`,`mediu`,`gro`,`eleventh`,`expected`,`diploma`,`mark`,`pregno`,`college`,`dept`,`doj`,`med`,`smat`,`sphy`,`sche`,`cmat`,`cphy`,`cche`,`amata`,`amatb`,`aphy`,`apphy`,`ache`,`apche`,`scutoff`,`percent`) VALUES ('$a', '$b', '$c', '$d','$w', '$g', '$h','$i', '$j','$k', '$l', '$m','$n','$o','$p','$q', '$r', '$s','$t','$file','$u','$v','$x','$key',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'$z','$mk')" ;
     
      $_SESSION["uniq"] = $key;
      $_SESSION["num"] = $g;
      if (mysqli_query($link,$sql,MYSQLI_USE_RESULT)) 
      {           
              if($t=="Regular")
              {
                          $user = $g;
                   header("Location:new.php?user=".$user);
              }
              else
              {
                  $user = $g;
                   header("Location:late.php?user=".$user);
              }
                   
      }
      $fields = array(
    "sender_id" => "FSTSMS",
    "message" => "Dear $a $b, Thanks for registration with Velammal Institute of Technology. Your Reference Number is : $key. Use this Number to login for further updation. For any clarification please contact : 9087556789.",
    "language" => "english",
    "route" => "p",
    "numbers" => "$g",
);

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.fast2sms.com/dev/bulk",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_SSL_VERIFYHOST => 0,
  CURLOPT_SSL_VERIFYPEER => 0,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode($fields),
  CURLOPT_HTTPHEADER => array(
    "authorization: CoQKLXTr78tnlqNOkzcb0hS3ygY1WIGJVm4EFjHA9wf6BMuUDaTxCHhi5yIdGlaQ3wmDUj4rk0Fq16fp",
    "accept: */*",
    "cache-control: no-cache",
    "content-type: application/json"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);
      
    
    // if ($err) {
    //   echo "cURL Error #:" . $err;
    // } else {
    //   echo $response;
    // }



      mysqli_close($link);
   
}
?>

<center><h1><img src="img/vitlogo.png" width="60%"/></h1></center>
    <section class="container-fluid bg">
        <section class="row justify-content-center">
            <section class="col col-sm-6 col-md-6 col-lg-4 col-xl-6">
              <div class="row justify-content-center align-items-center h-100">
                <form method="post" action="registration.php" enctype="multipart/form-data">
                  <div class="form-group">
                    <center><h4>ONLINE ADMISSION FORM</h4></center>
                  </div>
                    <div class="form-group">
                      <label for="exampleInputName">First Name</label>
                      <input type="text" name="fname" class="form-control" id="exampleInputName1" placeholder="First Name" maxlength="30">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputName">Last Name</label>
                      <input type="text" name="lname" class="form-control" id="exampleInputName2"  placeholder="Last Name" maxlength="30" >
                    </div>
                    <div class="form-group">
                        <label for="exampleInputDob">Date of Birth</label>
                        <input type="date" name="dob" class="form-control" id="exampleInputDob" size="50">
                      </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email Address</label>
                        <input type="email" name="email" class="form-control" id="exampleInputEmail1"  placeholder="Email Address">
                    <span id="namelocemai"></span>
                    </div>
                    <div class="form-group">Gender</div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio1" name="gender" value="Male" class="custom-control-input">
                        <label class="custom-control-label" for="customRadio1">Male</label>
                      </div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio2" name="gender" value="Female" class="custom-control-input">
                        <label class="custom-control-label" for="customRadio2">Female</label>
                      </div><br>
                    <div class="form-group">
                        <label for="exampleInputName">Contact Number</label>
                        <input type="text" name="num" class="form-control" id="exampleInputName5" placeholder="Mobile Number" minlength="10" maxlength="10" required>
                        <span id="namelocparentcont"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Alternate Number</label>
                        <input type="text" name="anum" class="form-control" id="exampleInputName6" placeholder="Mobile Number" minlength="10" maxlength="10">
                      </div>
                      <div class="form-group">Living with</div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio3" name="living"  value="parent" class="custom-control-input">
                        <label class="custom-control-label" for="customRadio3">Parent</label>
                      
                    </div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio4" name="living" value="guardian" class="custom-control-input">
                        <label class="custom-control-label" for="customRadio4">Guardian</label>
                      </div><br>
                      <div class="form-group">
                        <label for="exampleInputName">Parent/Guardian Name</label>
                        <input type="text" name="pname" class="form-control" onmouseout="passname()" id="exampleInputName3" placeholder="Parent/Guardian Name" maxlength="30" required >
                        <span id="namelocparent"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Parent/Guardian Occupation</label>
                        <input type="text" name="poccu" class="form-control" id="exampleInputName10" onmouseout="passoccname()" placeholder="Parent/Guardian Occupation" maxlength="30" required>
                         <span id="namelocparentocc"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Mother Tongue</label>
                        <input type="text" name="mtongue" class="form-control" id="exampleInputName4" onmouseout="passtonname()" placeholder="Mother Tongue" maxlength="30" >
                        <span id="namelocparentton"></span>
                      </div>
                      
                      <div class="form-group">
                        <label for="exampleInputName">10th Percentage</label>
                        <input type="text" name="tenth" class="form-control" id="exampleInputName7" placeholder="10th Percentage" minlength="2"  maxlength="2" required>
                        <span id="namelocparentper"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputNamep">12th Percentage</label>
                        <input type="text" name="percent" class="form-control" id="exampleInputNamep" placeholder="12th Percentage" minlength="2"  maxlength="2" required>
                      </div>
                      <div class="form-group">
                        <label for="inputAddress">Address</label>
                        <input type="textarea" name="address" class="form-control" id="inputAddress" onmouseout="passaddname()" placeholder="Address" maxlength="300" >
                        <span id="namelocparentadd"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlSelect2">District</label>
                        <select class="form-control" id="exampleFormControlSelect2" name="district" onmouseout="passdistname()">
                            <option value="">Select</option>
                            <option value="Ariyalur">Ariyalur</option>
	                    <option value="Chengalpattu">Chengalpattu </option>
                            <option value="Chennai">Chennai </option>
                            <option value="Coimbatore">Coimbatore</option>
                            <option value="Cuddalore">Cuddalore </option>
                            <option value="Dharmapuri">Dharmapuri</option>
                            <option value="Dindigul">Dindigul </option>
                            <option value="Erode">Erode</option>
                            <option value="Kallakurichi">Kallakurichi </option>
                            <option value="Kanchipuram">Kanchipuram </option>
                            <option value="Kanyakumari">Kanyakumari </option>
                            <option value="Karur">Karur</option>
                            <option value="Krishnagiri">Krishnagiri </option>
                            <option value="Madurai">Madurai </option>
                            <option value="Nagappattinam">Nagappattinam</option>
                            <option value="Namakkal">Namakkal </option>
                            <option value="Perambalur">Perambalur</option>
                            <option value="Pudukkottai">Pudukkottai</option>
                            <option value="Ramanathapuram">Ramanathapuram </option>
                            <option value="Ranipet">Ranipet </option>
                            <option value="Salem ">Salem </option>
                            <option value="Sivagangai">Sivagangai </option>
                            <option value="Tenkasi">Tenkasi </option>
                            <option value="Thanjavur">Thanjavur</option>
                            <option value="Nilgiris">Nilgiris </option>
                            <option value="Theni">Theni </option>
                            <option value="Thirupattur">Thirupattur </option>
                            <option value="Thoothukudi">Thoothukudi </option>
                            <option value="Tiruchirappalli">Tiruchirappalli</option>
                            <option value="Tirunelveli">Tirunelveli </option>
                            <option value="Tiruppur">Tiruppur </option>
                            <option value="Tiruvallur">Tiruvallur </option>
                            <option value="Tiruvannamalai">Tiruvannamalai </option>
                            <option value="Tiruvarur">Tiruvarur</option>
                            <option value="Vellore">Vellore </option>
                            <option value="Viluppuram">Viluppuram </option>
                            <option value="Virudhunagar">Virudhunagar </option>
                            <option value="Others">Others</option>
                        </select>
                        <span id="namelocparentdist"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlSelect3">State</label>
                        <select class="form-control" id="exampleFormControlSelect3" name="state" onmouseout="passstatename()">
                          <option value="select">Select</option>
                          <option value="Tamil Nadu">Tamil Nadu</option>
                          <option value="Andhra Pradesh">Andhra Pradesh</option>
                          <option value="Telangana">Telangana</option>
                          <option value="Karnataka">Karnataka</option>
                          <option value="Others">Others</option>
                        </select>
                        <span id="namelocparentstate"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Pincode</label>
                        <input type="text" class="form-control" id="exampleInputName8" name="pincode" onmouseout="passpinname()" placeholder="Pincode"  minlength="6" maxlength="6" required oninvalid="this.setCustomValidity('number must be  6 digits')" onchange="this.setCustomValidity('')">
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlSelect1">Religion</label>
                        <select class="form-control" id="exampleFormControlSelect1" onmouseout="livinname()" name="religion">
                          <option value="select">Select</option>
                          <option value="hindu">Hindu</option>
                          <option value="christian">Christian</option>
                          <option value="muslim">Muslim</option>
                          <option value="others">Others</option>
                        </select>
                        <span id="nameloclivin"></span>
                      </div>
                  
                      <div class="form-group">From where you filled the Application form ?</div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio5" name="registered" value="Home" class="custom-control-input">
                        <label class="custom-control-label" for="customRadio5" >Home</label>
                      </div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio6" name="registered" value="Browsing Center" class="custom-control-input">
                        <label class="custom-control-label" for="customRadio6">Browsing Center</label>
                      </div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio7" name="registered" value="Velammal Institute Of Technology" class="custom-control-input">
                        <label class="custom-control-label" for="customRadio7">Velammal Institute Of Technology</label>
                      </div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio8" name="registered" value="Others" class="custom-control-input">
                        <label class="custom-control-label" for="customRadio8">Others</label>
                      </div><br>
                      <div class="form-group">Select Type</div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio9" name="choice" class="custom-control-input" value="Regular">
                        <label class="custom-control-label" for="customRadio9" >B.E/B.TECH (REGULAR)</label>
                      </div>
                      <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio10" name="choice" class="custom-control-input" value="Lateral">
                        <label class="custom-control-label" for="customRadio10">B.E/B.TECH (LATERAL)</label>
                      </div><br>
                      <div class="form-group">
                          <b><label for="exampleFormControlFile1">Upload Your Passport Size Photo</label></b>
                        <input type="file" class="form-control-file" id="exampleFormControlFile1"  name="image" >
                      </div>
                      <div class="form-group">
                        <h4 style="text-align: center;">Course Preference</h4>
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlSelect4">First Preference</label>
                        <select class="form-control" id="exampleFormControlSelect4" name="fpre" required>
                          <option value="" style="color: black">First Preference</option>
                          <option value="INFORMATION TECHNOLOGY" style="color: black">INFORMATION TECHNOLOGY</option>
                          <option value="COMPUTER SCIENCE ENGINEERING" style="color: black">COMPUTER SCIENCE ENGINEERING</option>
                          <option value="MECHANICAL ENGINEERING" style="color: black">MECHANICAL ENGINEERING</option>
                          <option value="ELECTRICAL & ELECTRONIC ENGINEERING" style="color: black">ELECTRICAL & ELECTRONIC ENGINEERING</option>
                          <option value="ELECTRONICS & COMMUNICATION ENGINEERING" style="color: black">ELECTRONICS & COMMUNICATION ENGINEERING</option>
                          <option value="MECHATRONICS ENGINEERING" style="color: black">MECHATRONICS ENGINEERING</option>
                          <option value="ARTIFICIAL INTELLIGENCE AND DATA SCIENCE" style="color: black">ARTIFICIAL INTELLIGENCE AND DATA SCIENCE</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlSelect5">Second Preference</label>
                        <select class="form-control" id="exampleFormControlSelect5" name="spre" required>
                          <option value="" style="color: black">Second Preference</option>
                          <option value="INFORMATION TECHNOLOGY" style="color: black">INFORMATION TECHNOLOGY</option>
                          <option value="COMPUTER SCIENCE ENGINEERING" style="color: black">COMPUTER SCIENCE ENGINEERING</option>
                          <option value="MECHANICAL ENGINEERING" style="color: black">MECHANICAL ENGINEERING</option>
                          <option value="ELECTRICAL & ELECTRONIC ENGINEERING" style="color: black">ELECTRICAL & ELECTRONIC ENGINEERING</option>
                          <option value="ELECTRONICS & COMMUNICATION ENGINEERING" style="color: black">ELECTRONICS & COMMUNICATION ENGINEERING</option>
                          <option value="MECHATRONICS ENGINEERING" style="color: black">MECHATRONICS ENGINEERING</option>
                          <option value="ARTIFICIAL INTELLIGENCE AND DATA SCIENCE" style="color: black">ARTIFICIAL INTELLIGENCE AND DATA SCIENCE</option>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlSelect6">Third Preference</label>
                        <select class="form-control" id="exampleFormControlSelect6" name="tpre" required>
                          <option value="" style="color: black">Third Preference</option>
                          <option value="INFORMATION TECHNOLOGY" style="color: black">INFORMATION TECHNOLOGY</option>
                          <option value="COMPUTER SCIENCE ENGINEERING" style="color: black">COMPUTER SCIENCE ENGINEERING</option>
                          <option value="MECHANICAL ENGINEERING" style="color: black">MECHANICAL ENGINEERING</option>
                          <option value="ELECTRICAL & ELECTRONIC ENGINEERING" style="color: black">ELECTRICAL & ELECTRONIC ENGINEERING</option>
                          <option value="ELECTRONICS & COMMUNICATION ENGINEERING" style="color: black">ELECTRONICS & COMMUNICATION ENGINEERING</option>
                          <option value="MECHATRONICS ENGINEERING" style="color: black">MECHATRONICS ENGINEERING</option>
                          <option value="ARTIFICIAL INTELLIGENCE AND DATA SCIENCE" style="color: black">ARTIFICIAL INTELLIGENCE AND DATA SCIENCE</option>
                        </select>
                      </div><br>
                      <center><input type="submit" class="btn btn-lg  btn-outline-primary" value="NEXT > >" name="submit" id="submit"  onclick="myFunction()" ></center>
                  </form>
                </div>
            </section>
        </section>

    </section>
<!-- <script type="text/javascript">
function Upload() {
    //Get reference of FileUpload.
    var fileUpload = document.getElementById("exampleFormControlFile1");
 
    //Check whether the file is valid Image.
    var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(.jpg|.png|.gif)$");
    if (regex.test(fileUpload.value.toLowerCase())) {
 
        //Check whether HTML5 is supported.
        if (typeof (fileUpload.files) != "undefined") {
            //Initiate the FileReader object.
            var reader = new FileReader();
            //Read the contents of Image File.
            reader.readAsDataURL(fileUpload.files[0]);
            reader.onload = function (e) {
                //Initiate the JavaScript Image object.
                var image = new Image();
 
                //Set the Base64 string return from FileReader as source.
                image.src = e.target.result;
                       
                //Validate the File Height and Width.
                image.onload = function () {
                    var height = this.height;
                    var width = this.width;
                    if (height > 500 || width > 500) {
                        alert("Height and Width must not exceed 100px.");
                        return false;
                    }
                    alert("Uploaded image has valid Height and Width.");
                    return true;
                };
 
            }
        } else {
            alert("This browser does not support HTML5.");
            return false;
        }
    } else {
        alert("Please select a valid Image file.");
        return false;
    }
}
</script> -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    
</body>

</html>
 