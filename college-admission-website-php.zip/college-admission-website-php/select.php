<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
    <link rel="stylesheet" href="test.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<body>
    <?php
    $b=$_SESSION["def"];
    $_SESSION["abc"]=$b;
?>
    <div>
        <center><img src="img/vit.png" height="50%" width="50%"></center>
    </div>
    <br>
    <center>
    <div style="border: 1px solid black;padding: 15px;margin: 15px;width:50%">
        <marquee> <div class="panel-body" style="color: crimson;font-weight: 700; font-size: medium;">Choose your respective board of study and fill in your 12th marks...</div></marquee>
    </div>
    </center>
    <div class="container">
        <div class="radio-tile-group">
          <div class="input-container">
            <input id="walk" class="radio-button" type="radio" name="radio" />
            <div class="radio-tile">
              <div class="icon walk-icon">
                <!-- <svg fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M0 0h24v24H0z" fill="none"/>
                  <path d="M13.5 5.5c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zM9.8 8.9L7 23h2.1l1.8-8 2.1 2v6h2v-7.5l-2.1-2 .6-3C14.8 12 16.8 13 19 13v-2c-1.9 0-3.5-1-4.3-2.4l-1-1.6c-.4-.6-1-1-1.7-1-.3 0-.5.1-.8.1L6 8.3V13h2V9.6l1.8-.7"/>
                
                </svg> -->
                <label for="walk" class="radio-tile-label1"> <b> UPDATE </b></label>
              </div>
              
            </div>
          </div>
      
          <div class="input-container">
            <input id="bike" class="radio-button" type="radio" name="radio" />
            <div class="radio-tile">
              <div class="icon bike-icon">
                <!-- <svg fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M0 0h24v24H0z" fill="none"/>
                  <path d="M15.5 5.5c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zM5 12c-2.8 0-5 2.2-5 5s2.2 5 5 5 5-2.2 5-5-2.2-5-5-5zm0 8.5c-1.9 0-3.5-1.6-3.5-3.5s1.6-3.5 3.5-3.5 3.5 1.6 3.5 3.5-1.6 3.5-3.5 3.5zm5.8-10l2.4-2.4.8.8c1.3 1.3 3 2.1 5.1 2.1V9c-1.5 0-2.7-.6-3.6-1.5l-1.9-1.9c-.5-.4-1-.6-1.6-.6s-1.1.2-1.4.6L7.8 8.4c-.4.4-.6.9-.6 1.4 0 .6.2 1.1.6 1.4L11 14v5h2v-6.2l-2.2-2.3zM19 12c-2.8 0-5 2.2-5 5s2.2 5 5 5 5-2.2 5-5-2.2-5-5-5zm0 8.5c-1.9 0-3.5-1.6-3.5-3.5s1.6-3.5 3.5-3.5 3.5 1.6 3.5 3.5-1.6 3.5-3.5 3.5z"/>
                </svg> -->
                 <label for="bike" class="radio-tile-label2"> <b> STATEBOARD </b></label>
              </div>
            </div>
          </div>
      
          <div class="input-container">
            <input id="drive" class="radio-button" type="radio" name="radio" />
            <div class="radio-tile">
              <div class="icon car-icon">
                <!-- <svg fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z"/>
                  <path d="M0 0h24v24H0z" fill="none"/>
                </svg> -->
                <label for="drive" class="radio-tile-label3"> <b> CBSE </b></label>
              </div>
              
            </div>
          </div>
      
          <div class="input-container">
            <input id="fly" class="radio-button" type="radio" name="radio" />
            <div class="radio-tile">
              <div class="icon fly-icon">
                <!-- <svg fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M10.18 9"/>
                  <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"/>
                  <path d="M0 0h24v24H0z" fill="none"/>
                </svg> -->
                <label for="fly" class="radio-tile-label4"> <b> Andhra Pradhesh </b></label>
              </div>
              <!-- <label for="fly" class="radio-tile-label">Andhra Pradhesh</label> -->
            </div>
          </div>
        </div>
      </div>
      <center>
    <div style="border: 1px solid black;padding: 15px;margin: 15px;width:50%">
        <marquee> <div class="panel-body" style="color: crimson;font-weight: 700; font-size: medium;">For any updation in registration form click on update button...</div></marquee>
    </div>
    </center>
      <script>
        document.getElementById("walk").onclick = function () {
            location.href = "registration1.php";
        };
        document.getElementById("bike").onclick = function () {
            location.href = "state.php";
        };
        document.getElementById("drive").onclick = function () {
            location.href = "cbse.php";
        };
        document.getElementById("fly").onclick = function () {
            location.href = "andhra.php";
        };
        </script>
</body>
</html>