<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PDF</title>
    <link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
    <link rel="stylesheet" href="style.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<style>
         .bg{
    background-size: 100%;
    background-color: #fff;
}
.container {
    background: #fff;
    padding: 30px;
    border-radius:30px ;
    box-shadow: 0px 0px 15px 0px #000;
}
    </style>
  </head>
<body>
<div class="row">
      <center><p class="h1"><img src="img/vitlogo.png" width=80% style="align-content: center;" alt="logo" ></p></center>
      </div>
<div class="container_123">
      <div class="cont">
      <div class="col-md-6 mx-auto text-center">
         <div class="header-title">
            <h2 class="wv-heading--title">
               PDF
            </h2>
         </div>
      </div>
   </div>
   <div class="container">
      <div class="row">
         <div class="col-md-4 mx-auto">
            <div class="myform form ">
               <form action="data.php" method="post" >
               <div class="form-group">
                    <label for="exampleInputName" style="font-weight: 500;">Reference Number or Mobile Number</label>
                    <input type="text" name="pdf" class="form-control my-input" id="exampleInputName1" placeholder="Reference Number or Mobile Number" >
                </div>
                <center><input type="submit" class="btn btn-lg btn-outline-primary" name="submit" value="Submit" id="submit"></center>
                </form>
              </div>
            </div>
            </div>
          </div>
</body>
</html>