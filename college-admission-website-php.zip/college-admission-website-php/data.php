<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>My page</title>
  <link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <style>
    table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  width: 95%;
}
th, td {
  padding: 5px;
  text-align: left;    
}

    </style>
</head>
<body>
<?php

$link =mysqli_connect("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
       
       // $user =  $_SESSION["email"] ;
         //$ss=$_SESSION["num"];
         $a = $_POST['pdf'];
         //echo $a ;
       $sql = "SELECT `image`,`ref`,`fname`,`lname`,`dob`,`email`,`gender`,`num`,`anum`,`living`,`pname`,`poccu`,`mtongue`,`tenth`,`address`,`district`,`state`,`pincode`,`religion`,`registered`,`choice`,`fpre`,`spre`,`tpre`,`ref`,`regno`,`school`,`grou`,`vel`,`bos`,`mediu`,`gro`,`eleventh`,`expected`,`diploma`,`mark`,`pregno`,`college`,`dept`,`doj`,`med` FROM `vel` WHERE `num`='$a' OR `ref`='$a' ";
       $retval = mysqli_query( $link, $sql );
     while($row = mysqli_fetch_array($retval)) {
       //mysqli_close($link);
	
?>
<center><h1><img src="img/vitlogo.png" width="70%"/></h1></center>            
<center><h2 style="font-family:Times New Roman">APPLICATION FORM</h2></center>
<center>
             <table class="tg" style="table-layout:fixed; width:80%;">
        <thead>              
       <tr>
         <td style="font-weight: bold;text-align: center">DESCRIPTION</td>
         <td style="font-weight: bold ;text-align: center" colspan="2">DETAILS</td>
       </tr>
       </thead>
       <tbody>        
 <tr>
    <td style="font-weight: bold">APPLICATION NUMBER</td>
    <td><strong></strong><?php echo $row['ref'] ?></td>
    <td rowspan="4" style="font-size:18px"><?php echo '<img src="data:image;base64,'.base64_encode($row['image']).'"alt="Image" style="width: 200px; height: 150px" >'?> </td>
  </tr>
  <tr>
    <td style="font-weight: bold">FIRST NAME</td>
    <td style="font-size:18px" cellpadding="7px"><?php echo $row['fname'] ?></td>
     </tr> 
  <tr>
    <td style="font-weight: bold">LAST NAME</td>
    <td style="font-size:18px" cellpadding="7px"><?php echo $row['lname'] ?></td>
  </tr>
  <tr>
    <td style="font-weight: bold">DATE OF BIRTH</td>
    <td style="font-size:18px" cellpadding="7px"> <?php echo $row['dob'] ?> </td>
  </tr>
  <tr>
         <td style="font-weight: bold">CONTACT NUMBER</td>
         <td  style="font-size:18px" colspan="2"><?php echo $row['num'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">ALTERNATE NUMBER</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['anum'] ?> </td>
       </tr>
  <tr>
    <td style="font-weight: bold">EMAIL ID</td>
    <td style="font-size:18px" colspan="2"><?php echo $row['email'] ?> </td>
  </tr>
  
       <tr>
         <td style="font-weight: bold">LIVING WITH<br></td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['living'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">PARENT/GUARDIAN NAME</td>
         <td style="font-size:18px"colspan="2"> <?php echo $row['pname'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">PARENT/GUARDIAN OCCUPATION</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['poccu'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">MOTHER TONGUE</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['mtongue'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">10th PERCENTAGE</td>
         <td  style="font-size:18px"colspan="2"> <?php echo $row['tenth'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">ADDRESS</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['address'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">DISTRICT</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['district'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">STATE</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['state'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">PINCODE</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['pincode'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">FIRST PREFERENCE</td>
         <td  style="font-size:18px"colspan="2"> <?php echo $row['fpre'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">SECOND PREFERENCE</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['spre'] ?> </td>
       </tr>
        <tr>
         <td style="font-weight: bold">THIRD PREFERENCE</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['tpre'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">GENDER</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['gender'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">CHOICE</td>
         <td  style="font-size:18px"colspan="2"> <?php echo $row['choice'] ?></td>
       </tr>
  <?php if($row['choice']=="Regular") {?>
       <tr>
         <td style="font-weight: bold">12th Registration Number</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['regno'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">12th School Name</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['school'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">12th Group</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['grou'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Are you from Velammal Group</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['vel'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Board Of Study</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['bos'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Medium Of Instruction</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['mediu'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Group</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['gro'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">11th Percentage</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['eleventh'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">12th Expected Mark</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['expected'] ?> </td>
       </tr>
  <?php } else { ?>
       <tr>
         <td style="font-weight: bold">Qualifying Exam Type</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['diploma'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">12th Mark (In % If Applicable)</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['mark'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Registration Number (Diploma)</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['pregno'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">College</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['college'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Department in Diploma</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['dept'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Date of Joining (Diploma)</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['doj'] ?> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Medium Of Instruction</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['med'] ?> </td>
       </tr>
  
       <tr>
         <td style="font-weight: bold">Where you registered?</td>
         <td  style="font-size:18px"colspan="2"><?php echo $row['registered'] ?> </td>
       </tr>
       <?php 
  }
    
}
?>
     </tbody>
     </table><br><br>
     <center>
       <p style="font-weight:bold;">For Further Details Contact || Mobile:9087556789 || Email:velammalinstituteadmission@gmail.com</p>
       </center>
     </center>
     <center>
         <button type="button" value="Print" onClick="window.print()" class="btn-outline-primary btn-lg" >Print</button>
         
     </center>
         </body>
</html>