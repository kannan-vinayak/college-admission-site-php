<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>B.E/B.TECH LATERAL</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<?php
 $link =new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
        if(!$link)
        {
           die('could not connect: ' . $link->connect_error());
        }
        $user=$_GET['user'];
       //$user = $_SESSION["email"];
        
       $sql = "SELECT `diploma`,`mark`,`pregno`,`college`,`dept`,`doj`,`med` FROM `vel` WHERE `ref`='$user' OR `num`='$user' ";
       $retval = mysqli_query( $link, $sql );
   
   while($row = mysqli_fetch_array($retval)) {
  
  ?>

<body>
      <div class="row">
      <center><p class="h1"><img src="img/vitlogo.png" width=80% style="align-content: center;" alt="logo" ></p></center>
      </div>
   <div class="container_123">
      <div class="cont">
      <div class="col-md-6 mx-auto text-center">
         <div class="header-title">
            <h1 class="wv-heading--title">
               B.E/B.TECH LATERAL
            </h1>
         </div>
      </div>
   </div>
   <div class="container">
      <div class="row">
         <div class="col-md-4 mx-auto">
            <div class="myform form ">
               <form class="form-container" action=<?php echo "late1up.php?user=".$user; ?> method="post" enctype="multipart/form-data">
               <div class="form-group">
              <label for="exampleInputName" style="font-weight: 500;">Qualifying Exam Type</label>
              <input type="text" name="diploma" class="form-control my-input" id="exampleInputName12" value="<?php echo $row['diploma'] ?>" >
          </div>
          <div class="form-group">
              <label for="exampleInputName" style="font-weight: 500;">12th Mark (In % If Applicable)</label>
              <input type="number" name="mark" class="form-control my-input" id="exampleInputName1" value="<?php echo $row['mark'] ?>" minlength="2"  maxlength="3">
              <span id="nameloc12"></span>
          </div>
          <div class="form-group">
              <label for="exampleInputName" style="font-weight: 500;">Registration Number (Diploma)</label>
              <input type="number" name="pregno" class="form-control my-input" id="exampleInputName2" value="<?php echo $row['pregno'] ?>" minlength="8"  maxlength="15" >
              <span id="namelocreg"></span>
          </div>
          <div class="form-group">
              <label for="exampleInputName" style="font-weight: 500;">College</label>
              <input type="text" name="college" class="form-control my-input" id="exampleInputName4" value="<?php echo $row['college'] ?>">
              <span id="namelocdcol"></span>
          </div>
          <div class="form-group">
              <label for="exampleInputName" style="font-weight: 500;">Department in Diploma</label>
              <input type="text" name="dept" class="form-control my-input" id="exampleInputName3" value="<?php echo $row['dept'] ?>">
              <span id="namelocdname"></span>
          </div>
          <div class="form-group">

              <label for="exampleInputName" style="font-weight: 500;">Year Of Completion</label>
              <input type="text" name="doj" class="form-control my-input" id="exampleInputName5" value="<?php echo $row['doj'] ?>">
          </div>
          <div class="form-group">
              <label for="exampleFormControlSelect2">Medium Of Instruction</label>
              <select class="form-control my-input" id="exampleFormControlSelect2" name="med" >
                  <option value="<?php echo $row['med'] ?>" style="color: black"><?php echo $row['med'] ?></option>
                  <option value="english" style="color: black">English</option>
                  <option value="tamil" style="color: black">Tamil</option>
                  <option value="telugu" style="color: black">Telegu</option>
                  <option value="other" style="color: black">Other</option>
              </select>
              <span id="namelocdmed"></span>
          </div>

          <?php

}
?>
          <center><button type="submit" class="btn btn-lg btn-outline-primary" name="submit" value="submit"  id="submit">Submit</button></center>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</body>
</body>
</html>