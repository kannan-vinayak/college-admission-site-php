<?php  
      //export.php  
  
      $connect = mysqli_connect("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");  
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=db.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('id','Reference Number','First Name','Last Name','Date Of Birth','Email Address','Gender','Contact Number','Alternate Number','Living With','Parent/Guardian Name','Parent/Guardian Occupation','Mother Tongue','10th %','12th %','Address','District','State','Pincode','Relegion','From Where Registered','Type','First Preference','Second Preference','Third Preference','12th Registration Number','12th School Name','Type','Velammal Group','Board Of Study','Medium','12th Group','11th Percentage','12th Expected','Diploma','12th Mark ','Registration Number','College','Department in Diploma','Date of Joining','Medium Of Instruction','State Board Maths','State Board Physics','State Board Chemistry','AP Maths A','AP Maths B','AP Physics','AP Practical Physics','AP Chemistry','AP Practical Chemistry','CBSE Maths','CBSE Physics','CBSE Chemistry','Cutoff','entry'));  
      $query = "SELECT `id`,`ref`,`fname`,`lname`,`dob`,`email`,`gender`,`num`,`anum`,`living`,`pname`,`poccu`,`mtongue`,`tenth`,`percent`,`address`,`district`,`state`,`pincode`,`religion`,`registered`,`choice`,`fpre`,`spre`,`tpre`,`regno`,`school`,`grou`,`vel`,`bos`,`mediu`,`gro`,`eleventh`,`expected`,`diploma`,`mark`,`pregno`,`college`,`dept`,`doj`,`med`,`smat`,`sphy`,`sche`,`cmat`,`cphy`,`cche`,`amata`,`amatb`,`aphy`,`apphy`,`ache`,`apche`,`scutoff`,`entry` FROM `vel`"; 
	  $result = mysqli_query($connect, $query, MYSQLI_USE_RESULT);
     while($row =mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);   
 ?>  