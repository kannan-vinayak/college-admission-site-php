<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>B.E/B.TECH LATERAL</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<?php
 $link =new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
        if(!$link)
        {
           die('could not connect: ' . $link->connect_error());
        }
        $user=$_GET['user'];
       //$user = $_SESSION["email"];
  if(isset($_POST['submit']))
{
         
         $a=$_POST['diploma'];
         $c=$_POST['mark'];
         $d=$_POST['pregno'];
         $e=$_POST['college'];
         $f=$_POST['dept'];
         $g=$_POST['doj'];
         $h=$_POST['med'];

         $sql = " UPDATE `vel` SET  `diploma`='$a',`mark`='$c',`pregno`='$d',`college`='$e',`dept`='$f',`doj`='$g',`med`='$h' WHERE `num` ='$user' ";
         
       if (mysqli_query($link,$sql,MYSQLI_USE_RESULT)) 
       {           
                header("Location:middle.php");          
       }

       mysqli_close($link);
	
} ?>

<body>
      <div class="row">
      <center><p class="h1"><img src="img/vitlogo.png" width=80% style="align-content: center;" alt="logo" ></p></center>
      </div>
   <div class="container_123">
      <div class="cont">
      <div class="col-md-6 mx-auto text-center">
         <div class="header-title">
            <h1 class="wv-heading--title">
               B.E/B.TECH LATERAL
            </h1>
         </div>
      </div>
   </div>
   <div class="container">
      <div class="row">
         <div class="col-md-4 mx-auto">
            <div class="myform form ">
               <form class="form-container" action=<?php echo "late.php?user=".$user; ?> method="post" enctype="multipart/form-data">
                <div class="form-group" style="font-weight: 500;">Qualifying Exam Type</div>
                <div class="custom-control custom-radio">
                  <input type="radio" id="customRadio1" name="diploma" value="Diploma" class="custom-control-input" >
                  <label class="custom-control-label" for="customRadio1">Diploma</label>
                </div>
                <div class="custom-control custom-radio">
                  <input type="radio" id="customRadio2" name="diploma" value="B.Sc" class="custom-control-input">
                  <label class="custom-control-label" for="customRadio2">B.Sc</label>
                </div><br>
                <span id="nameloc"></span>
          <div class="form-group">
              <label for="exampleInputName" style="font-weight: 500;">12th Mark (In % If Applicable)</label>
              <input type="number" name="mark" class="form-control my-input" id="exampleInputName1" placeholder="12th Mark (In % If Applicable)" minlength="2"  maxlength="3">
              <span id="nameloc12"></span>
          </div>
          <div class="form-group">
              <label for="exampleInputName" style="font-weight: 500;">Registration Number (Diploma)</label>
              <input type="number" name="pregno" class="form-control my-input" id="exampleInputName2" placeholder="Registration Number (Diploma)" minlength="8"  maxlength="15" >
              <span id="namelocreg"></span>
          </div>
          <div class="form-group">
              <label for="exampleInputName" style="font-weight: 500;">College</label>
              <input type="text" name="college" class="form-control my-input" id="exampleInputName4" placeholder="College">
              <span id="namelocdcol"></span>
          </div>
          <div class="form-group">
              <label for="exampleInputName" style="font-weight: 500;">Department in Diploma</label>
              <input type="text" name="dept" class="form-control my-input" id="exampleInputName3" placeholder="Department in Diploma">
              <span id="namelocdname"></span>
          </div>
          <div class="form-group">

              <label for="exampleInputName" style="font-weight: 500;">Year Of Completion</label>
              <input type="text" name="doj" class="form-control my-input" id="exampleInputName5" placeholder="Year Of Completion">
          </div>
          <div class="form-group">
              <label for="exampleFormControlSelect2">Medium Of Instruction</label>
              <select class="form-control my-input" id="exampleFormControlSelect2" name="med" >
                  <option value="none" style="color: black">Medium of Instruction</option>
                  <option value="english" style="color: black">English</option>
                  <option value="tamil" style="color: black">Tamil</option>
                  <option value="telugu" style="color: black">Telegu</option>
                  <option value="other" style="color: black">Other</option>
              </select>
              <span id="namelocdmed"></span>
          </div>
          <center><button type="submit" class="btn btn-lg btn-outline-primary" name="submit" value="submit"  id="submit">Submit</button></center>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</body>
</body>
</html>