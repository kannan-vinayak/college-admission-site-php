<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
    <?php
        $link = new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
        $aq=$_SESSION["abc"]; 
        if(!$link)
        {
           die('could not connect: ' . $link->connect_error());
        }
        if(isset($_POST['submit']))
        {
        $a=$_POST['m1'];
        $b=$_POST['m2'];
        $c=$_POST['m3'];
        $z=0;$t=0;$x=100;$qp=100;$qo=100;
        $z=($z+$a)*50/$x;
        $t=($t+$b)*25/$qp;
        $y=($y+$c)*25/$qo;
        $ab=$z+$t+$y;
        $bn = number_format($ab,2)*2;
        $_SESSION["cutoff"] = $bn;
        $sql="UPDATE `vel` SET `cmat`='$a',`cphy`='$b',`cche`='$c',`scutoff`='$bn' WHERE `num`='$aq' OR `ref`='$aq' ";
        if (mysqli_query($link,$sql,MYSQLI_USE_RESULT)) 
        {
            header("Location:lastpdf.php");
        }
        else{
            header("Location:login.php");
        }
        }
    ?>
<div class="container_123">
      <div class="cont">
      <div class="col-md-6 mx-auto text-center">
         <div class="header-title">
            <h2 class="wv-heading--title">
                CBSE
            </h2>
         </div>
      </div>
   </div>
   <div class="container">
      <div class="row">
         <div class="col-md-4 mx-auto">
            <div class="myform form ">
               <form action="cbse.php" method="post">
               <div class="form-group">
                    <label for="exampleInputName" style="font-weight: 500;">Maths</label>
                    <input type="text" name="m1" class="form-control my-input" id="exampleInputName1" placeholder="Enter Your Maths Mark(out of 100)" minlength="2"  maxlength="2">
                </div>
                <div class="form-group">
                    <label for="exampleInputName" style="font-weight: 500;">Physics</label>
                    <input type="text" name="m2" class="form-control my-input" id="exampleInputName1" placeholder="Enter Your Physics Mark(out of 100)" minlength="2"  maxlength="2">
                </div>
                <div class="form-group">
                    <label for="exampleInputName" style="font-weight: 500;">Chemistry</label>
                    <input type="text" name="m3" class="form-control my-input" id="exampleInputName1" placeholder="Enter Your Chemistry Mark(out of 100)" minlength="2"  maxlength="2">
                </div>
                <center><button type="submit" class="btn btn-lg btn-outline-primary" name="submit" value="submit"  id="submit">Submit</button></center>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>   
</body>
</html>