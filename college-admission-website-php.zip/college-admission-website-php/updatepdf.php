<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>My page</title>
  <link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <style>
    table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  width: 95%;
}
th, td {
  padding: 5px;
  text-align: left;    
}

    </style>
</head>
<body>
<?php

$link =mysqli_connect("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
       
        
       // $user =  $_SESSION["email"] ;
         $ss=$_SESSION["abc"];
       $sql = "SELECT `image`,`ref`,`fname`,`lname`,`dob`,`email`,`gender`,`num`,`anum`,`living`,`pname`,`poccu`,`mtongue`,`tenth`,`address`,`district`,`state`,`pincode`,`religion`,`registered`,`choice`,`fpre`,`spre`,`tpre`,`ref`,`regno`,`school`,`grou`,`vel`,`bos`,`mediu`,`gro`,`eleventh`,`expected`,`diploma`,`mark`,`pregno`,`college`,`dept`,`doj`,`med` FROM `vel` WHERE `ref`='$ss' OR `num`='$ss' ";
       $retval = mysqli_query( $link, $sql );
     
     while($row = mysqli_fetch_array($retval)) {
       //mysqli_close($link);

       $qp=$row['ref'];
       $qw='<img src="data:image;base64,'.base64_encode($row['image']).'"alt="Image" style="width: 200px; height: 150px" >';
       $_SESSION["abc"]=$qp;
	
?>
<center><h1><img src="img/vitlogo.png" width="70%"/></h1></center>            
<center><h2 style="font-family:Times New Roman">APPLICATION FORM</h2></center>
<form action="updatepdf" method="post">
<center>
             <table class="tg" style="table-layout:fixed; width:80%;">
        <thead>              
       <tr>
         <td style="font-weight: bold;text-align: center">DESCRIPTION</td>
         <td style="font-weight: bold ;text-align: center" colspan="2">DETAILS</td>
       </tr>
       </thead>
       <tbody>        
 <tr>
    <td style="font-weight: bold">APPLICATION NUMBER</td>
    <td><strong></strong><?php echo $qp; ?></td>
    <td rowspan="4" style="font-size:18px"><?php echo $qw ?> </td>
  </tr>
  <tr>
    <td style="font-weight: bold">FIRST NAME</td>
    <td style="font-size:18px" cellpadding="7px"> <input type="text" name="fname" id="fname" value="<?php echo $row['fname'] ?>"></td>
     </tr> 
  <tr>
    <td style="font-weight: bold">LAST NAME</td>
    <td style="font-size:18px" cellpadding="7px"> <input type="text" name="lname" id="lname" value="<?php echo $row['lname'] ?>"></td>
  </tr>
  <tr>
    <td style="font-weight: bold">DATE OF BIRTH</td>
    <td style="font-size:18px" cellpadding="7px"> <input type="text" name="dob" id="dob" value="<?php echo $row['dob'] ?>"> </td>
  </tr>
  <tr>
         <td style="font-weight: bold">CONTACT NUMBER</td>
         <td  style="font-size:18px" colspan="2"> <input type="text" name="num" id="num" value="<?php echo $row['num'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">ALTERNATE NUMBER</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="anum" id="anum" value="<?php echo $row['anum'] ?>"> </td>
       </tr>
  <tr>
    <td style="font-weight: bold">EMAIL ID</td>
    <td style="font-size:18px" colspan="2"> <input type="text" name="email" id="email" value="<?php echo $row['email'] ?>"> </td>
  </tr>
  
       <tr>
         <td style="font-weight: bold">LIVING WITH<br></td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="living" id="living" value="<?php echo $row['living'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">PARENT/GUARDIAN NAME</td>
         <td style="font-size:18px"colspan="2"> <input type="text" name="pname" id="pname" value=<?php echo $row['pname'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">PARENT/GUARDIAN OCCUPATION</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="poccu" id="poccu" value="<?php echo $row['poccu'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">MOTHER TONGUE</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="mtongue" id="mtongue" value="<?php echo $row['mtongue'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">10th PERCENTAGE</td>
         <td  style="font-size:18px"colspan="2">  <input type="text" name="tenth" id="tenth" value="<?php echo $row['tenth'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">ADDRESS</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="address" id="address" value="<?php echo $row['address'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">DISTRICT</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="district" id="district" value="<?php echo $row['district'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">STATE</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="state" id="state" value="<?php echo $row['state'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">PINCODE</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="pincode" id="pincode" value="<?php echo $row['pincode'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">FIRST PREFERENCE</td>
         <td  style="font-size:18px"colspan="2">  <input type="text" name="fpre" id="fpre" value="<?php echo $row['fpre'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">SECOND PREFERENCE</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="spre" id="spre" value="<?php echo $row['spre'] ?>"> </td>
       </tr>
        <tr>
         <td style="font-weight: bold">THIRD PREFERENCE</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="tpre" id="tpre" value="<?php echo $row['tpre'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">GENDER</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="gender" id="gender" value="<?php echo $row['gender'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">CHOICE</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="choice" id="choice" value="<?php echo $row['choice'] ?>"></td>
       </tr>
  <?php if($row['choice']=="Regular") {?>
       <tr>
         <td style="font-weight: bold">12th Registration Number</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="regno" id="regno" value="<?php echo $row['regno'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">12th School Name</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="school" id="school" value="<?php echo $row['school'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">12th Group</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="grou" id="grou" value="<?php echo $row['grou'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Are you from Velammal Group</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="vel" id="vel" value="<?php echo $row['vel'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Board Of Study</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="bos" id="bos" value="<?php echo $row['bos'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Medium Of Instruction</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="mediu" id="mediu" value="<?php echo $row['mediu'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Group</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="gro" id="gro" value="<?php echo $row['gro'] ?>"> </td>
       </tr>
        <tr>
         <td style="font-weight: bold">11th Percentage</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="eleventh" id="eleventh" value="<?php echo $row['eleventh'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">12th Expected Mark</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="expected" id="expected" value="<?php echo $row['expected'] ?>"> </td>
       </tr>
  <?php } else { ?>
       <tr>
         <td style="font-weight: bold">Qualifying Exam Type</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="diploma" id="diploma" value="<?php echo $row['diploma'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">12th Mark (In % If Applicable)</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="mark" id="mark" value="<?php echo $row['mark'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Registration Number (Diploma)</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="pregno" id="pregno" value="<?php echo $row['pregno'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">College</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="college" id="college" value="<?php echo $row['college'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Department in Diploma</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="dept" id="dept" value="<?php echo $row['dept'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Date of Joining (Diploma)</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="doj" id="doj" value="<?php echo $row['doj'] ?>"> </td>
       </tr>
       <tr>
         <td style="font-weight: bold">Medium Of Instruction</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="med" id="med" value="<?php echo $row['med'] ?>"> </td>
       </tr>
  
       <tr>
         <td style="font-weight: bold">Where you registered?</td>
         <td  style="font-size:18px"colspan="2"> <input type="text" name="registered" id="registered" value="<?php echo $row['registered'] ?>"> </td>
       </tr>
       <?php 
    }
}?>
     </tbody>
     </table><br><br>
     </center>
     <center><input type="submit" class="btn btn-lg  btn-outline-primary" value="Update" name="submit" id="submit" ></center>
                  </form>
                  <?php
                  if(isset($_POST['submit']))
{    
        $a=$_POST['fname'];
        $b=$_POST['lname'];
        $c=$_POST['dob'];
        $d=$_POST['email'];
        $w=$_POST['gender'];
        $g=$_POST['num'];
        $h=$_POST['anum'];
        $i=$_POST['living'];
        $j=$_POST['pname'];
        $k=$_POST['poccu'];
        $l=$_POST['mtongue'];
        $m=$_POST['tenth'];
        $n=$_POST['address'];
        $o=$_POST['district'];
        $p=$_POST['state'];
        $q=$_POST['pincode'];
        $r=$_POST['religion'];
        $s=$_POST['registered'];
        $t=$_POST['choice'];
        $u=$_POST['fpre'];
        $v=$_POST['spre'];
        $x=$_POST['tpre'];
        $z=1111;
        $key= $qp;
        $file=$qw;
        $a1=$_POST['regno'];
         $b1=$_POST['school'];
         $c1=$_POST['grou'];
         $d1=$_POST['vel'];
         $e1=$_POST['bos'];
         $f1=$_POST['mediu'];
         $g1=$_POST['gro'];
         $ij1=$_POST['eleventh'];
         $h1=$_POST['expected'];
         $a2=$_POST['diploma'];
         $c2=$_POST['mark'];
         $d2=$_POST['pregno'];
         $e2=$_POST['college'];
         $f2=$_POST['dept'];
         $g2=$_POST['doj'];
         $h2=$_POST['med'];
         $sql = "UPDATE `vel` SET `fname`= '$a',`lname`='$b',`dob`='$c',`email`='$d',`gender`='$w',`num`='$g',`anum`='$h',`living`='$i',
         `pname`='$j',`poccu`='$k',`mtongue`='$l',`tenth`='$m',`address`='$n',`district`='$o',`state`='$p',`pincode`='$q',
         `religion`='$r',`registered`='$s',`choice`='$t',`image`='$file',`fpre`='$u',`spre`='$v',`tpre`='$x',`ref`='$key',
         `regno`='$a1',`school`='$b1',`grou`='$c1',`vel`='$d1',`bos`='$e1',`mediu`='$f1',`gro`='$g1',`eleventh`='$ij1',`expected`='$h1',
         `diploma`='$a2',`mark`='$c2',`pregno`='$d2',`college`='$e2',`dept`='$f2',`doj`='$g2',`med`='$h2' WHERE `ref`='$ss' OR `num`='$ss'";
        if (mysqli_query($link,$sql,MYSQLI_USE_RESULT)) 
        {           
                 header("Location:pdf1.php");          
        }
      }
        ?>
 
         </body>
</html>

