<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark</title>
    
</head>
<body>
    <?php
        $link = new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
        $a=$_SESSION["abc"];
        $sql="SELECT `bos` FROM `vel` WHERE `num`='$a' OR `ref`='$a' limit 1";
        $c=mysqli_query($link,$sql);
        $b=mysqli_fetch_row($c);
        $d=$b[0];
        
        $sql="SELECT `scutoff` FROM `vel` WHERE `num`='$a' OR `ref`='$a' limit 1";
        $z=mysqli_query($link,$sql);
        $o=mysqli_fetch_row($z);
        $q=$o[0];
        if($q == 1111)
        {
            if($d == 'state'){
                header("Location:state.php");
            }
            elseif($d == 'central')
            {
                header("Location:cbse.php");
            }
            else{
                header("Location:andhra.php");
            }
        }   
    else{
        header("Location:magic.php");
    }
        ?>
    
</body>
</html>