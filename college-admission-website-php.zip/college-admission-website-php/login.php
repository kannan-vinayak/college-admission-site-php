<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
        <link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/e1fb7b13f7.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php
        $link = new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
        if(!$link)
        {
           die('could not connect: ' . $link->connect_error());
        }
        if(isset($_POST['email']))
        {    
        $a=$_POST['email'];

		$sql="SELECT * FROM `vel` WHERE `num`='$a' OR `ref`='$a' limit 1";
		$_SESSION["def"] = $a;
		$result = mysqli_query($link,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
	  $count = mysqli_num_rows($result);

        if($count == 1){
			echo "success" ;
            header("Location:select.php");

        }
        else{
			echo "Failed";
            header("Location:index.html");
        }
    }
    mysqli_close($link);
     ?>
	<div class="container">
		<div class="img">
			<img src="img/bg1.svg">
		</div>
		<div class="login-content">
			<form method="post" action="login.php">
				<img src="img/avatar.png">
				<h2 class="title" style="font-size :35px;">LOGIN</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-envelope"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>Mobile Number or Reference Number</h5>
           		   		<input type="text" class="input" name="email">
           		   </div>
           		</div>
            	<button type="submit" class="btn" value="submit" name="submit" id="submit">LOGIN</button>
            </form>
        </div>
	</div>
	<script src="js/main.js"></script>
        
</body>
</html>