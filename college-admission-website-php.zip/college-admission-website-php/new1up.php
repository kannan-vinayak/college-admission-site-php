<?php
    session_start();
?>
<?php
$link = new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
if(!$link)
{
   die('could not connect: ' . $link->connect_error());
}
$user=$_GET['user'];
  if(isset($_POST['submit']))
{
         $a=$_POST['regno'];
         $b=$_POST['school'];
         $c=$_POST['grou'];
         $d=$_POST['vel'];
         $e=$_POST['bos'];
         $f=$_POST['mediu'];
         $g=$_POST['gro'];
         $ij=$_POST['eleventh'];
         $h=$_POST['expected'];
         $ss=$_SESSION["abc"];
       $sql = "UPDATE `vel` SET `regno`='$a',`school`='$b',`grou`='$c',`vel`='$d',`bos`='$e',`mediu`='$f',`gro`='$g',`eleventh`='$ij',`expected`='$h' WHERE `num`='$user' OR `ref`='$user'";
       if (mysqli_query($link,$sql,MYSQLI_USE_RESULT)) 
       {           
                 header("Location:pdf1.php");         
       }

       mysqli_close($link);
	
}
?>