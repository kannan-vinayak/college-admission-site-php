<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>B.E/B.TECH REGULAR</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
   <?php
$link = new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
        if(!$link)
        {
           die('could not connect: ' . $link->connect_error());
        }
$user=$_GET['user'];
//$user = $_SESSION["email"];
  if(isset($_POST['submit']))
{
         $a=$_POST['regno'];
         $b=$_POST['school'];
         $c=$_POST['grou'];
         $d=$_POST['vel'];
         $e=$_POST['bos'];
         $f=$_POST['mediu'];
         $g=$_POST['gro'];
         $ij=$_POST['eleventh'];
         //$h=$_POST['expected'];
         
       $sql = "UPDATE `vel` SET `regno`='$a',`school`='$b',`grou`='$c',`vel`='$d',`bos`='$e',`mediu`='$f',`gro`='$g',`eleventh`='$ij' WHERE `num`='$user' ";
       if (mysqli_query($link,$sql,MYSQLI_USE_RESULT)) 
       {           
                 header("Location:middle.php");         
       }

       mysqli_close($link);
	
}
?>
      <div class="row">
      <center><p class="h1"><img src="img/vitlogo.png" width=80% style="align-content: center;" alt="logo" ></p></center>
      </div>
   <div class="container_123">
      <div class="cont">
      <div class="col-md-6 mx-auto text-center">
         <div class="header-title">
            <h1 class="wv-heading--title">
               B.E/B.TECH REGULAR
            </h1>
         </div>
      </div>
   </div>
   <div class="container">
      <div class="row">
         <div class="col-md-4 mx-auto">
            <div class="myform form ">
               <form action=<?php echo "new.php?user=".$user; ?> class="form-container" method="post" enctype="multipart/form-data">
                  <div class="form-group">
                     <label for="exampleInputName" style="font-weight: 500;">12th Registration Number</label>
                     <input type="text" name="regno"id="exampleInputName1"  class="form-control my-input" id="name" placeholder="12th Registration Number">
                  </div>
                  <div class="form-group">
                     <label for="exampleInputName" style="font-weight: 500;">12th School Name</label>
                     <input type="text" name="school" class="form-control my-input" id="exampleInputName2" placeholder="12th School Name">
                     <span id="namelocsname"></span>
                 </div>
                 <div class="form-group" style="font-weight: 500;">12th Group</div>
                       <div class="custom-control custom-radio" >
                         <input type="radio" id="customRadio1" name="grou" value="General" class="custom-control-input">
                         <label class="custom-control-label" for="customRadio1">General</label>
                       </div>
                       <div class="custom-control custom-radio">
                         <input type="radio" id="customRadio2" name="grou" value="Vocational" class="custom-control-input">
                         <label class="custom-control-label" for="customRadio2">Vocational</label><br>
                       </div>
                     
                      <br>
                 <div class="form-group" style="font-weight: 500;">Are you from Velammal Group</div>
                       <div class="custom-control custom-radio">
                         <input type="radio" id="customRadio3" name="vel" value="Yes" class="custom-control-input">
                         <label class="custom-control-label" for="customRadio3">Yes</label>
                       </div>
                       <div class="custom-control custom-radio">
                         <input type="radio" id="customRadio4" name="vel" value="No" class="custom-control-input">
                         <label class="custom-control-label" for="customRadio4">No</label>
 
                       </div><br>
                 <div class="form-group">
                     <label for="exampleFormControlSelect1" style="font-weight: 500;">Board Of Study</label>
                         <select class="form-control my-input" id="exampleFormControlSelect1" name="bos">
                             <option value="select" style="color: black">Board of Study</option>
                             <option value="central" style="color: black">Central</option>
                             <option value="state" style="color: black">State Board(TN State)</option>
                             <option value="intermediate" style="color: black">Intermediate(AP state)</option>
                             <option value="other" style="color: black">Other</option>
                         </select>
                         <span id="namelocbos"></span>
                 </div>
                 <div class="form-group">
                     <label for="exampleFormControlSelect2" style="font-weight: 500;">Medium Of Instruction</label>
                     <select class="form-control my-input" id="exampleFormControlSelect2" name="mediu" >
                         <option value="select" style="color: black">Medium of Instruction</option>
                         <option value="english" style="color: black">English</option>
                         <option value="tamil" style="color: black">Tamil</option>
                         <option value="telugu" style="color: black">Telegu</option>
                         <option value="other" style="color: black">Other</option>
                     </select>
                     <span id="namelocmedium"></span>
 
                 </div>
                 <div class="form-group">
                     <label for="exampleFormControlSelect3" style="font-weight: 500;">Group</label>
                     <select class="form-control my-input" id="exampleFormControlSelect3" name="gro" >
                         <option value="group">Group</option>
                         <option value="phy||che||comp||mat" style="color: black">phy||che||comp||mat</option>
                         <option value="phy||che||sta||mat"style="color: black">phy||che||sta||mat</option>
                         <option value="phy||che||bio||mat"style="color: black">phy||che||bio||mat</option>
                         <option value="phy||che||bio-che||mat" style="color: black">phy||che||bio-che||mat</option> 
                         <option value="other" style="color: black">Other</option>
                     </select>
                     <span id="namelocgrup"></span>
                 </div>
                 <div class="form-group" style="font-weight: 500;">
                  <label for="exampleInputName">11th Percentage</label>
                  <input type="text" name="eleventh" class="form-control my-input" id="exampleInputName4" placeholder="11th Percentage" minlength="2"  maxlength="2" required>
                  <span id="namelocmark"></span>
              </div>
                 <!--<div class="form-group" style="font-weight: 500;">-->
                 <!--    <label for="exampleInputName">12th Expected Percentage</label>-->
                 <!--    <input type="text" name="expected" class="form-control my-input" id="exampleInputName3" placeholder="12th Expected Percentage" minlength="2"  maxlength="2" required>-->
                 <!--    <span id="namelocmark"></span>-->
                 <!--</div>-->
                 <center><input type="submit" class="btn btn-lg btn-outline-primary" name="submit" value="submit" id="submit"></center>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</body>
</html>