<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>B.E/B.TECH REGULAR</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
   <?php
$link = new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
        if(!$link)
        {
           die('could not connect: ' . $link->connect_error());
        }
$user=$_GET['user'];

    $sql = "SELECT `regno`,`school`,`grou`,`vel`,`bos`,`mediu`,`gro`,`eleventh`,`expected` FROM `vel` WHERE `ref`='$user' OR `num`='$user' ";
    $retval = mysqli_query( $link, $sql );

while($row = mysqli_fetch_array($retval)) {
?>
      <div class="row">
      <center><p class="h1"><img src="img/vitlogo.png" width=80% style="align-content: center;" alt="logo" ></p></center>
      </div>
   <div class="container_123">
      <div class="cont">
      <div class="col-md-6 mx-auto text-center">
         <div class="header-title">
            <h1 class="wv-heading--title">
               B.E/B.TECH REGULAR
            </h1>
         </div>
      </div>
   </div>
   <div class="container">
      <div class="row">
         <div class="col-md-4 mx-auto">
            <div class="myform form ">
               <form action=<?php echo "new1up.php?user=".$user; ?> class="form-container" method="post" enctype="multipart/form-data">
                  <div class="form-group">
                     <label for="exampleInputName" style="font-weight: 500;">12th Registration Number</label>
                     <input type="text" name="regno"id="exampleInputName1"  class="form-control my-input" id="name" value="<?php echo $row['regno'] ?>">
                  </div>
                  <div class="form-group">
                     <label for="exampleInputName" style="font-weight: 500;">12th School Name</label>
                     <input type="text" name="school" class="form-control my-input" id="exampleInputName2" value="<?php echo $row['school'] ?>">
                     <span id="namelocsname"></span>
                 </div>
                 <div class="form-group">
                     <label for="exampleFormControlSelect10" style="font-weight: 500;">12th Group</label>
                         <select class="form-control my-input" id="exampleFormControlSelect10" name="grou">
                             <option value="<?php echo $row['grou'] ?>" style="color: black"><?php echo $row['grou'] ?></option>
                             <option value="General" style="color: black">General</option>
                             <option value="Vocationl" style="color: black">Vocational</option>
                         </select>
                 </div>
                 <div class="form-group">
                     <label for="exampleFormControlSelect10" style="font-weight: 500;">Are you from Velammal Group</label>
                         <select class="form-control my-input" id="exampleFormControlSelect10" name="vel">
                             <option value="<?php echo $row['vel'] ?>" style="color: black"><?php echo $row['vel'] ?></option>
                             <option value="Yes" style="color: black">Yes</option>
                             <option value="No" style="color: black">No</option>
                         </select>
                         <span id="namelocvel"></span>
                 </div>
                 <div class="form-group">
                     <label for="exampleFormControlSelect1" style="font-weight: 500;">Board Of Study</label>
                         <select class="form-control my-input" id="exampleFormControlSelect1" name="bos">
                             <option value="<?php echo $row['bos'] ?>" style="color: black"><?php echo $row['bos'] ?></option>
                             <option value="central" style="color: black">Central</option>
                             <option value="state" style="color: black">State Board(TN State)</option>
                             <option value="intermediate" style="color: black">Intermediate(AP state)</option>
                             <option value="other" style="color: black">Other</option>
                         </select>
                         <span id="namelocbos"></span>
                 </div>
                 <div class="form-group">
                     <label for="exampleFormControlSelect2" style="font-weight: 500;">Medium Of Instruction</label>
                     <select class="form-control my-input" id="exampleFormControlSelect2" name="mediu" >
                         <option value="<?php echo $row['mediu']?>" style="color: black"><?php echo $row['mediu'] ?></option>
                         <option value="english" style="color: black">English</option>
                         <option value="tamil" style="color: black">Tamil</option>
                         <option value="telugu" style="color: black">Telegu</option>
                         <option value="other" style="color: black">Other</option>
                     </select>
                     <span id="namelocmedium"></span>
 
                 </div>
                 <div class="form-group">
                     <label for="exampleFormControlSelect3" style="font-weight: 500;">Group</label>
                     <select class="form-control my-input" id="exampleFormControlSelect3" name="gro" >
                         <option value="<?php echo $row['gro'] ?>"><?php echo $row['gro'] ?></option>
                         <option value="phy||che||comp||mat" style="color: black">phy||che||comp||mat</option>
                         <option value="phy||che||sta||mat"style="color: black">phy||che||sta||mat</option>
                         <option value="phy||che||bio||mat"style="color: black">phy||che||bio||mat</option>
                         <option value="phy||che||bio-che||mat" style="color: black">phy||che||bio-che||mat</option> 
                         <option value="other" style="color: black">Other</option>
                     </select>
                     <span id="namelocgrup"></span>
                 </div>
                 <div class="form-group" style="font-weight: 500;">
                  <label for="exampleInputName">11th Percentage</label>
                  <input type="text" name="eleventh" class="form-control my-input" id="exampleInputName4" value="<?php echo $row['eleventh'] ?>">
                  <span id="namelocmark"></span>
              </div>
                 <div class="form-group" style="font-weight: 500;">
                     <label for="exampleInputName">12th Expected Percentage</label>
                     <input type="text" name="expected" class="form-control my-input" id="exampleInputName3" value="<?php echo $row['expected'] ?>">
                     <span id="namelocmark"></span>
                 </div>
                 <center><input type="submit" class="btn btn-lg btn-outline-primary" name="submit" value="submit" id="submit"></center>
               
               <?php
            }
               ?>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</body>
</html>