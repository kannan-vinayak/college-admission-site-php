<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Result</title>
        <style>
        .bg{
    background-size: 100%;
    background-color: gray;
}
.form-container {
    margin-top: 10%;
    margin-left: 15%;
    width: 70%;
    background: #fff;
    padding:20px;
    border-radius:10px ;
    box-shadow: 0px 0px 15px 0px #000;
}
    </style>
    </head>
    <body>
        <div class="form-container">
            <?php
            $as = $_SESSION["cutoff"];
            ?>
    <center>
        <h2>CUTOFF - <?php  echo $as ?></h2>
        <h1>Your Application Form has been Successfully Updated</h1>
        <p style="font-size:20px">Click here to <a href="magic.php">Download PDF</a></p>
    </center>
        </div>
    </body>
</html>
