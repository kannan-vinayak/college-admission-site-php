<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Velammal Institute of Technology</title>
    <link rel="shortcut icon"  type="image/png" href="img/favicon.png"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/52874c72f6.js" crossorigin="anonymous"></script>
    <script src="main.js" type="text/js"></script>
    <style>
         .bg{
    background-size: 100%;
    background-color: #fff;
}
.form-container {
    width: 100%;
    position: absolute;
    top: 5vh;
    background: #fff;
    padding: 30px;
    border-radius:25px ;
    box-shadow: 0px 0px 25px 0px #000;
}
    </style>
</head>
<body>
<?php
$link =new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
if(!$link)
{
  die('could not connect: ' . $link->connect_error());
}
        
         $ss=$_SESSION["abc"];
       $sql = "SELECT `image`,`ref`,`fname`,`lname`,`dob`,`email`,`gender`,`num`,`anum`,`living`,`pname`,`poccu`,`mtongue`,`tenth`,`percent`,`address`,`district`,`state`,`pincode`,`religion`,`registered`,`choice`,`fpre`,`spre`,`tpre`,`ref` FROM `vel` WHERE `ref`='$ss' OR `num`='$ss' ";
       $retval = mysqli_query( $link, $sql );
     
     while($row = mysqli_fetch_array($retval)) {
       $qp=$row['ref'];
       $_SESSION["abccd"]=$qp;
?>

<center><h1><img src="img/vitlogo.png" width="60%"/></h1></center>
    <section class="container-fluid bg">
        <section class="row justify-content-center">
            <section class="col col-sm-6 col-md-6 col-lg-4 col-xl-6">
              <div class="row justify-content-center align-items-center h-100">
                <form method="post" action="regup.php">
                  <div class="form-group">
                    <center><h4>ONLINE ADMISSION FORM</h4></center>
                  </div>
                  <div class="form-group">
                  <center>
                  <p style="font-size:18px"><?php echo '<img src="data:image;base64,'.base64_encode($row['image']).'"alt="Image" style="width: 200px; height: 150px" >'?> </p></center>
                  </div>
                  <div class="form-group">
                      <label for="exampleInputRef">Unique Reference Number</label>
                      <input type="text" name="ref" class="form-control" id="exampleInputRef" value="<?php echo $qp ?>" readonly>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputName">First Name</label>
                      <input type="text" name="fname" class="form-control" id="exampleInputName1" value="<?php echo $row['fname'] ?>" >
                    </div>
                    <div class="form-group">
                      <label for="exampleInputName">Last Name</label>
                      <input type="text" name="lname" class="form-control" id="exampleInputName2" value="<?php echo $row['lname'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputDob">Date of Birth</label>
                        <input type="date" name="dob" class="form-control" id="exampleInputDob" value="<?php echo $row['dob'] ?>" >
                      </div>
                      <div class="form-group">
                        <label for="exampleInputGender">Gender</label>
                        <input type="text" name="gender" class="form-control" id="exampleInputGender"  value="<?php echo $row['gender'] ?>" >
                      </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email Address</label>
                        <input type="text" name="email" class="form-control" id="exampleInputEmail" value="<?php echo $row['email'] ?>" >
                      </div>
                    <div class="form-group">
                        <label for="exampleInputNum">Contact Number</label>
                        <input type="text" name="num" class="form-control" id="exampleInputName5"  value="<?php echo $row['num'] ?>" >
                        <span id="namelocparentcont"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Alternate Number</label>
                        <input type="text" name="anum" class="form-control" id="exampleInputName6"  value="<?php echo $row['anum'] ?>" >
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Living With</label>
                        <input type="text" name="living" class="form-control" id="exampleInputName6anu"  value="<?php echo $row['living']?>" >
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Parent/Guardian Name</label>
                        <input type="text" name="pname" class="form-control" id="exampleInputName6pna" value="<?php echo $row['pname'] ?>">
                        <span id="namelocparent"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Parent/Guardian Occupation</label>
                        <input type="text" name="poccu" class="form-control" id="exampleInputName10" value="<?php echo $row['poccu'] ?>">
                         <span id="namelocparentocc"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Mother Tongue</label>
                        <input type="text" name="mtongue" class="form-control" id="exampleInputName4" value="<?php echo $row['mtongue'] ?>" >
                        <span id="namelocparentton"></span>
                      </div>
                      
                      <div class="form-group">
                        <label for="exampleInputName">10th Percentage</label>
                        <input type="text" name="tenth" class="form-control" id="exampleInputName7" value="<?php echo $row['tenth'] ?>" >
                        <span id="namelocparentper"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputNamep">12th Percentage</label>
                        <input type="text" name="percent" class="form-control" id="exampleInputNamep" value="<?php echo $row['percent'] ?>" >
                      </div>
                      <div class="form-group">
                        <label for="inputAddress">Address</label>
                        <input type="textarea" name="address" class="form-control" id="inputAddress" value="<?php echo $row['address'] ?>">
                        <span id="namelocparentadd"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlSelect2">District</label>
                        <input type="text" name="district" class="form-control" id="exampleInputName70" value="<?php echo $row['district'] ?>" >
                        <span id="namelocparentperc"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlSelect3">State</label>
                        <input type="text" name="state" class="form-control" id="exampleInputName75" value="<?php echo $row['state'] ?>" >
                        <span id="namelocparentstate"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Pincode</label>
                        <input type="text" class="form-control" id="exampleInputName8" name="pincode" value="<?php echo $row['pincode'] ?>" >
                      </div>
                      <div class="form-group">
                        <label for="exampleFormControlSelect1">Religion</label>
                        <input type="text" name="religion" class="form-control" id="exampleInputName7m" value="<?php echo $row['religion'] ?>">
                        <span id="nameloclivin"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">From where you filled the Application form ?</label>
                        <input type="text" name="registered" class="form-control" id="exampleInputName7r" value="<?php echo $row['registered'] ?>" >
                        <span id="namelocparentregistered"></span>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Select Type</label>
                        <input type="text" class="form-control" id="exampleInputName8c" name="choice" value="<?php echo $row['choice'] ?>" >
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">First Preference</label>
                        <input type="text" class="form-control" id="exampleInputName8fpre" name="fpre" value="<?php echo $row['fpre'] ?>">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Second Preference</label>
                        <input type="text" class="form-control" id="exampleInputName8spre" name="spre" value="<?php echo $row['spre'] ?>">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputName">Third Preference</label>
                        <input type="text" class="form-control" id="exampleInputName8tpre" name="tpre" value="<?php echo $row['tpre'] ?>">
                      </div>
                      <?php 
    }
    
    ?>
                      <br>
                      <center><input type="submit" class="btn btn-lg  btn-outline-primary" value="NEXT" name="submit" id="submit"  onclick="myFunction()" ></center>
                  </form>

                </div>
            </section>
        </section>
       
    </section>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>
 