<?php
    session_start();
?>
<?php
$link =new mysqli("sql309.freesite.vip","frsiv_25278397","kannanmohan","frsiv_25278397_velammal");
if(!$link)
{
  die('could not connect: ' . $link->connect_error());
}

$ss=$_SESSION["abc"];
$qp=$_SESSION["abccd"];

if(isset($_POST['submit']))
{    
        $a=$_POST['fname'];
        $b=$_POST['lname'];
        $c=$_POST['dob'];
        $d=$_POST['email'];
        $w=$_POST['gender'];
        $g=$_POST['num'];
        $h=$_POST['anum'];
        $i=$_POST['living'];
        $j=$_POST['pname'];
        $k=$_POST['poccu'];
        $l=$_POST['mtongue'];
        $m=$_POST['tenth'];
        $n=$_POST['address'];
        $o=$_POST['district'];
        $p=$_POST['state'];
        $q=$_POST['pincode'];
        $r=$_POST['religion'];
        $s=$_POST['registered'];
        $t=$_POST['choice'];
        $u=$_POST['fpre'];
        $v=$_POST['spre'];
        $x=$_POST['tpre'];
        $key = $qp;
        $sql = " UPDATE `vel` SET `fname`= '$a',`lname`='$b',`dob`='$c',`email`='$d',`gender`='$w',`num`='$g',`anum`='$h',`living`='$i',
        `pname`='$j',`poccu`='$k',`mtongue`='$l',`tenth`='$m',`address`='$n',`district`='$o',`state`='$p',`pincode`='$q',
        `religion`='$r',`registered`='$s',`choice`='$t',`fpre`='$u',`spre`='$v',`tpre`='$x',`ref`='$key'  WHERE `ref`='$ss' OR `num`='$ss'";
        $_SESSION["key1"] = $key;
        if (mysqli_query($link,$sql,MYSQLI_USE_RESULT)) 
        {

         if($t=="Regular")
              {
                          $user = $ss;
                   header("Location:new1.php?user=".$user);
              }
              else
              {
                  $user = $ss;
                   header("Location:late1.php?user=".$user);
              }
        }

}

?>
